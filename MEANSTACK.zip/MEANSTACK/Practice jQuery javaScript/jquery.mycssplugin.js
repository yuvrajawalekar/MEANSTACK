(function($){
   $.fn.mycss=function(){
        return this.each(function(){
		      $(this).css(
			  {
              "background-color":"blue",
              "color":"white",
              "border":"2px dashed red",
              "border-radius":"40px",
              "height":"200px",
              "width":"500px",
              "font-size":"24px"}
			  );
		});
   }
}
)(jQuery)