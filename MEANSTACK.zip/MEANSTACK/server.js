var http=require('http');
var url=require('url');
var fs=require('fs');


var onCreateServer=function(request, response){
    var pathname=url.parse(request.url).pathname;


fs.readFile(pathname.substr(1),function(err, data){
    if(err){
            console.log(err)
            response.writeHead(404,{'Content-Type': 'text/html'})
    }

    else{
        response.writeHead(200, {'Content-Type': 'text/html'});	
        response.write(data.toString());
    }
    response.end();
 



/*
    var data={
              title:"louts",
              quantity:4000,
              description:"Worship flower"};

    response.writeHead(200, {'Content-Type': 'application/json'});
    console.log(data);	
    var result=JSON.stringify(data);
    response.write(result);
    response.end();*/

});

}


var server=http.createServer(onCreateServer);
server.listen(9090);
console.log("server running at http://127.0.0.1:9090");
