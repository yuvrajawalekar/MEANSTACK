

exports.onDefault=function (req, res){
    res.sendFile(path.join(___dirname + '/index.html'));
}


exports.onBye=function(req, res){
    console.log("Calling rest api Bye");

    //invoke mysql connector 
    //access data from mysql database
    //receive data asynchrounous
    
    var person={message:'Bye Bye', emotion:'sad'};
    res.send(person);
}


exports.onHello=function(req, res){
    console.log("Calling rest api Hello");
    var person={firstName:'Ravi', lastName:'Tambade'};
    res.send(person);
}
