import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { from } from 'rxjs';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  userName:string='';
  password:string='';
  msg:string='';
  valid:boolean=false;

  constructor(public userService:UserService) { }

  ngOnInit() {
  }
  onLogin()
  {
    console.log(this.userName + this.password);
    this.valid=this.userService.authenticate({userName:this.userName, password: this.password});
    if(this.valid)
    {
      this.msg="Login Successful";
    }
    else
    {
      this.msg="Login Unsuccessful";
    }
    
  }

}
