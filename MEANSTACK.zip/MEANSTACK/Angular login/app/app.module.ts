import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
// 3.Import RouterModule into AppModule
import {RouterModule,Routes} from '@angular/router'
import { AppComponent } from './app.component';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { ListComponent } from './list/list.component';

import { UserService } from './user.service';
import { PassresetComponent } from './passreset/passreset.component';
import { JsonlistComponent } from './jsonlist/jsonlist.component';
import { EmployeeService } from './employee.service';





//1. Create all componenets
// 2.Creating Route Table
const appRoutes: Routes=[{path :'login', component: LoginComponent},
{path:'register', component:RegisterComponent},
{path:'list',component:ListComponent},
{path:'passreset',component:PassresetComponent},
{path:'jsonlist',component:JsonlistComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    LoginComponent,
    ListComponent,
    PassresetComponent,
    JsonlistComponent
  ],
  imports: [
    BrowserModule,FormsModule,
    //4. Registering routes with RouterModule.
    RouterModule.forRoot(appRoutes)
  ],
  providers: [UserService,EmployeeService],
  bootstrap: [AppComponent]
})
export class AppModule { }
