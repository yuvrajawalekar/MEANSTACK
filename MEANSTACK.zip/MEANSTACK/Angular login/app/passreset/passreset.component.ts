import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';

@Component({
  selector: 'app-passreset',
  templateUrl: './passreset.component.html',
  styleUrls: ['./passreset.component.css']
})
export class PassresetComponent implements OnInit {
  username:string = '';
  password:string = '';
  reset:boolean = false;
  msg:string = '';

  constructor(public svcpass: UserService) { }

  ngOnInit() {
  }

  onReset():any
  {
    this.reset=this.svcpass.changePassword({"UserName":this.username,"Password":this.password});
    if(this.reset)
    {
      this.msg="Password Changed";
    }
    else{
      this.msg="Password not changed";
    }
  }
}
