import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  userid:string='';
  username:string='';
  password:string='';
  msg:string='';

  constructor(public svc: UserService) { }

  ngOnInit() {
  }

  onRegister():any{
    this.msg=this.svc.addUser({"UserID":this.userid,"UserName":this.username,"Password":this.password});
    return this.msg;
  
  }
}
